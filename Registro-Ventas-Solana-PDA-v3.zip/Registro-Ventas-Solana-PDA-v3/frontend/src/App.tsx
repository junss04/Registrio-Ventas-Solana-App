import { useCallback, useEffect, useMemo, useState } from "react";
import { useAnchorWallet, useConnection } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { Data, PROGRAM_CONFIGURED, cargarTodo, getProgram, mensajeError, pdaCliente, pdaProducto, pdaRegistro, pdaVenta } from "./lib/chain";

type Tab = "dashboard" | "productos" | "clientes" | "ventas";
type Toast = { tipo: "ok" | "err"; texto: string; sig?: string };

export default function App() {
  const { connection } = useConnection();
  const wallet = useAnchorWallet();
  const [negocio, setNegocio] = useState(localStorage.getItem("negocio") || "");
  const [data, setData] = useState<Data | null>(null);
  const [cargado, setCargado] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [toast, setToast] = useState<Toast | null>(null);

  const program = useMemo(() => (wallet ? getProgram(connection, wallet) : null), [connection, wallet]);

  const refrescar = useCallback(async () => {
    if (!program || !wallet || !negocio) return;
    try { setData(await cargarTodo(program, negocio, wallet.publicKey)); setCargado(true); }
    catch (e) { setToast({ tipo: "err", texto: mensajeError(e) }); }
  }, [program, wallet, negocio]);

  useEffect(() => { setCargado(false); refrescar(); }, [refrescar]);

  // Envuelve cada operacion: firma, confirma, refresca y muestra errores del programa
  const run = async (etiqueta: string, fn: () => Promise<string>) => {
    setBusy(true); setToast(null);
    try { const sig = await fn(); setToast({ tipo: "ok", texto: etiqueta, sig }); await refrescar(); return true; }
    catch (e) { setToast({ tipo: "err", texto: mensajeError(e) }); return false; }
    finally { setBusy(false); }
  };

  const owner = wallet?.publicKey;
  const regKey = owner && negocio ? pdaRegistro(negocio, owner) : null;

  /////////// Acciones ///////////
  const crearRegistro = () => run("Registro creado", () =>
    program.methods.crearRegistro(negocio).accounts({ owner, registro: regKey }).rpc());

  const crearCliente = (nombre: string) => run("Cliente creado", () => {
    const id = data!.registro.idCounter + 1;
    return program.methods.crearCliente(nombre).accounts({ owner, registro: regKey, cliente: pdaCliente(regKey!, id) }).rpc();
  });
  const eliminarCliente = (id: number) => run("Cliente dado de baja", () =>
    program.methods.eliminarCliente(id).accounts({ owner, registro: regKey, cliente: pdaCliente(regKey!, id) }).rpc());

  const crearProducto = (sku: string, nombre: string, precio: number, stock: number) => run("Producto creado", () =>
    program.methods.crearProducto(sku, nombre, precio, stock).accounts({ owner, registro: regKey, producto: pdaProducto(regKey!, sku) }).rpc());
  const reabastecer = (sku: string, cantidad: number) => run("Stock actualizado", () =>
    program.methods.reabastecerProducto(sku, cantidad).accounts({ owner, registro: regKey, producto: pdaProducto(regKey!, sku) }).rpc());

  const cuentasVenta = (id: number, sku: string) => {
    const cliente = pdaCliente(regKey!, id);
    return { owner, registro: regKey, cliente, producto: pdaProducto(regKey!, sku), venta: pdaVenta(cliente, sku) };
  };
  const registrarVenta = (id: number, sku: string, desc: string, monto: number) => run("Venta registrada", () =>
    program.methods.registrarVenta(id, sku, desc, monto).accounts(cuentasVenta(id, sku)).rpc());
  const devolucion = (id: number, sku: string) => run("Devolución realizada", () =>
    program.methods.hacerDevolucion(id, sku).accounts(cuentasVenta(id, sku)).rpc());
  const cambiarMonto = (id: number, sku: string, nuevo: number) => run("Monto actualizado", () => {
    const { owner, registro, cliente, venta } = cuentasVenta(id, sku);
    return program.methods.cambiarMonto(id, sku, nuevo).accounts({ owner, registro, cliente, venta }).rpc();
  });

  /////////// Render ///////////
  return (
    <div className="app">
      <header>
        <div className="brand"><div className="logo">🧾</div><div><h1>Registro de <span>Ventas</span></h1><span className="sub">Programa on-chain en Solana · Devnet</span></div></div>
        <WalletMultiButton />
      </header>

      {!PROGRAM_CONFIGURED && <div className="banner warn">Falta configurar <code>VITE_PROGRAM_ID</code> en <code>frontend/.env</code> (el Program ID de tu deploy en Devnet).</div>}

      {!wallet ? <div className="card center">Conecta tu wallet (Phantom/Solflare en Devnet) para comenzar.</div> : (
        <>
          <NegocioBar negocio={negocio} onChange={(n) => { setNegocio(n); localStorage.setItem("negocio", n); }} />
          {negocio && cargado && !data && (
            <div className="card center">
              <p>No existe un registro llamado <b>{negocio}</b> para esta wallet.</p>
              <button disabled={busy} onClick={crearRegistro}>Crear registro</button>
            </div>
          )}
          {data && (
            <>
              <nav>{(["dashboard", "productos", "clientes", "ventas"] as Tab[]).map((t) =>
                <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>{t}</button>)}</nav>
              {tab === "dashboard" && <Dashboard data={data} />}
              {tab === "productos" && <Productos data={data} busy={busy} onCrear={crearProducto} onReabastecer={reabastecer} />}
              {tab === "clientes" && <Clientes data={data} busy={busy} onCrear={crearCliente} onEliminar={eliminarCliente} />}
              {tab === "ventas" && <Ventas data={data} busy={busy} onVenta={registrarVenta} onDevolucion={devolucion} onMonto={cambiarMonto} />}
            </>
          )}
        </>
      )}

      {busy && <div className="banner">Esperando firma y confirmación…</div>}
      {toast && (
        <div className={"toast " + toast.tipo} onClick={() => setToast(null)}>
          {toast.tipo === "ok" ? "✅ " : "⚠️ "}{toast.texto}
          {toast.sig && <> · <a href={`https://explorer.solana.com/tx/${toast.sig}?cluster=devnet`} target="_blank" rel="noreferrer">ver tx</a></>}
        </div>
      )}
    </div>
  );
}

function NegocioBar({ negocio, onChange }: { negocio: string; onChange: (n: string) => void }) {
  const [v, setV] = useState(negocio);
  return (
    <div className="card row">
      <label>Nombre del negocio (máx. 30)</label>
      <input value={v} maxLength={30} onChange={(e) => setV(e.target.value)} placeholder="Abarrotes Test" />
      <button onClick={() => onChange(v.trim())}>Abrir</button>
    </div>
  );
}

function Dashboard({ data }: { data: Data }) {
  const ingresos = Number(data.registro.ingresosTotales.toString());
  const promedio = data.ventas.length ? ingresos / data.ventas.length : 0;
  const bajos = data.productos.filter((p) => p.stock <= 2);
  const porCliente = data.clientes.map((c) => ({ ...c, total: data.ventas.filter((v) => v.clienteId === c.id).reduce((s, v) => s + v.monto, 0) })).sort((a, b) => b.total - a.total);
  const csv = () => {
    const filas = ["cliente,sku,descripcion,monto", ...data.ventas.map((v) => `"${v.clienteNombre}",${v.sku},"${v.descripcion}",${v.monto}`)];
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([filas.join("\n")], { type: "text/csv" }));
    a.download = "ventas.csv"; a.click();
  };
  return (
    <>
      <div className="stats">
        <Stat t="Ingresos (on-chain)" v={`$${ingresos}`} /><Stat t="Ventas" v={data.ventas.length} />
        <Stat t="Clientes" v={`${data.clientes.length}/10`} /><Stat t="Ticket promedio" v={`$${promedio.toFixed(2)}`} />
      </div>
      <div className="grid2">
        <div className="card"><h3>⚠️ Stock bajo (≤ 2)</h3>
          {bajos.length ? bajos.map((p) => <p key={p.sku}>{p.nombre} <b>({p.sku})</b>: {p.stock}</p>) : <p className="muted">Todo en orden</p>}</div>
        <div className="card"><h3>🏆 Mejores clientes</h3>
          {porCliente.filter((c) => c.total > 0).slice(0, 3).map((c) => <p key={c.id}>{c.nombre}: <b>${c.total}</b></p>)}
          {!porCliente.some((c) => c.total > 0) && <p className="muted">Sin ventas aún</p>}</div>
      </div>
      <button onClick={csv} disabled={!data.ventas.length}>⬇️ Exportar ventas (CSV)</button>
    </>
  );
}
const Stat = ({ t, v }: { t: string; v: any }) => <div className="card stat"><span>{t}</span><b>{v}</b></div>;

function Productos({ data, busy, onCrear, onReabastecer }: any) {
  const [sku, setSku] = useState(""); const [nombre, setNombre] = useState(""); const [precio, setPrecio] = useState(""); const [stock, setStock] = useState("");
  const [cant, setCant] = useState<Record<string, string>>({});
  return (
    <>
      <div className="card"><h3>Nuevo producto</h3>
        <div className="row">
          <input placeholder="SKU (máx. 5)" maxLength={5} value={sku} onChange={(e) => setSku(e.target.value)} />
          <input placeholder="Nombre" maxLength={30} value={nombre} onChange={(e) => setNombre(e.target.value)} />
          <input placeholder="Precio" type="number" min={1} value={precio} onChange={(e) => setPrecio(e.target.value)} />
          <input placeholder="Stock" type="number" min={0} value={stock} onChange={(e) => setStock(e.target.value)} />
          <button disabled={busy || !sku || !nombre || !precio} onClick={() => onCrear(sku, nombre, +precio, +stock || 0)}>Crear</button>
        </div></div>
      <div className="card"><h3>Inventario</h3>
        <table><thead><tr><th>SKU</th><th>Producto</th><th>Precio</th><th>Stock</th><th>Reabastecer</th></tr></thead><tbody>
          {data.productos.map((p: any) => (
            <tr key={p.sku}><td>{p.sku}</td><td>{p.nombre}</td><td>${p.precio}</td><td className={p.stock <= 2 ? "low" : ""}>{p.stock}</td>
              <td className="row"><input type="number" min={1} value={cant[p.sku] || ""} onChange={(e) => setCant({ ...cant, [p.sku]: e.target.value })} />
                <button disabled={busy || !+cant[p.sku]} onClick={() => onReabastecer(p.sku, +cant[p.sku])}>+</button></td></tr>))}
        </tbody></table>
        {!data.productos.length && <p className="muted">Aún no hay productos</p>}</div>
    </>
  );
}

function Clientes({ data, busy, onCrear, onEliminar }: any) {
  const [nombre, setNombre] = useState("");
  return (
    <>
      <div className="card"><h3>Nuevo cliente</h3>
        <div className="row"><input placeholder="Nombre (máx. 30)" maxLength={30} value={nombre} onChange={(e) => setNombre(e.target.value)} />
          <button disabled={busy || !nombre} onClick={async () => { if (await onCrear(nombre)) setNombre(""); }}>Crear</button></div></div>
      <div className="card"><h3>Clientes</h3>
        <table><thead><tr><th>ID</th><th>Nombre</th><th>Compras</th><th></th></tr></thead><tbody>
          {data.clientes.map((c: any) => (
            <tr key={c.id}><td>{c.id}</td><td>{c.nombre}</td><td>{c.compras}</td>
              <td><button className="danger" disabled={busy} title={c.compras ? "Tiene compras: el programa rechazará la baja" : ""}
                onClick={() => confirm(`¿Dar de baja a ${c.nombre}?`) && onEliminar(c.id)}>Dar de baja</button></td></tr>))}
        </tbody></table>
        {!data.clientes.length && <p className="muted">Aún no hay clientes</p>}</div>
    </>
  );
}

function Ventas({ data, busy, onVenta, onDevolucion, onMonto }: any) {
  const [cid, setCid] = useState(""); const [sku, setSku] = useState(""); const [desc, setDesc] = useState(""); const [monto, setMonto] = useState("");
  const [nuevo, setNuevo] = useState<Record<string, string>>({});
  const prod = data.productos.find((p: any) => p.sku === sku);
  return (
    <>
      <div className="card"><h3>Registrar venta</h3>
        <div className="row">
          <select value={cid} onChange={(e) => setCid(e.target.value)}><option value="">Cliente…</option>
            {data.clientes.map((c: any) => <option key={c.id} value={c.id}>{c.id} · {c.nombre}</option>)}</select>
          <select value={sku} onChange={(e) => { setSku(e.target.value); const p = data.productos.find((x: any) => x.sku === e.target.value); if (p) setMonto(String(p.precio)); }}>
            <option value="">Producto…</option>
            {data.productos.map((p: any) => <option key={p.sku} value={p.sku} disabled={p.stock === 0}>{p.sku} · {p.nombre} ({p.stock})</option>)}</select>
          <input placeholder="Descripción" maxLength={50} value={desc} onChange={(e) => setDesc(e.target.value)} />
          <input placeholder="Monto" type="number" min={1} value={monto} onChange={(e) => setMonto(e.target.value)} />
          <button disabled={busy || !cid || !sku || !+monto || prod?.stock === 0} onClick={() => onVenta(+cid, sku, desc, +monto)}>Vender</button>
        </div></div>
      <div className="card"><h3>Historial de ventas</h3>
        <table><thead><tr><th>Cliente</th><th>SKU</th><th>Descripción</th><th>Monto</th><th>Cambiar monto</th><th></th></tr></thead><tbody>
          {data.ventas.map((v: any) => { const k = v.key.toBase58(); return (
            <tr key={k}><td>{v.clienteNombre}</td><td>{v.sku}</td><td>{v.descripcion}</td><td>${v.monto}</td>
              <td className="row"><input type="number" min={1} value={nuevo[k] || ""} onChange={(e) => setNuevo({ ...nuevo, [k]: e.target.value })} />
                <button disabled={busy || !+nuevo[k]} onClick={() => onMonto(v.clienteId, v.sku, +nuevo[k])}>✓</button></td>
              <td><button className="danger" disabled={busy} onClick={() => confirm("¿Devolver esta venta?") && onDevolucion(v.clienteId, v.sku)}>Devolver</button></td></tr>); })}
        </tbody></table>
        {!data.ventas.length && <p className="muted">Aún no hay ventas</p>}</div>
    </>
  );
}
