import { AnchorProvider, Program, Idl } from "@coral-xyz/anchor";
import { Connection, PublicKey } from "@solana/web3.js";
import idlJson from "../idl/registro.json";

export const PROGRAM_ID = new PublicKey(import.meta.env.VITE_PROGRAM_ID || "11111111111111111111111111111111");
export const PROGRAM_CONFIGURED = !!import.meta.env.VITE_PROGRAM_ID;

export function getProgram(connection: Connection, wallet: any) {
  const provider = new AnchorProvider(connection, wallet, { commitment: "confirmed" });
  return new Program({ ...(idlJson as any), address: PROGRAM_ID.toBase58() } as Idl, provider) as any;
}

const u16 = (n: number) => { const b = new Uint8Array(2); new DataView(b.buffer).setUint16(0, n, true); return b; };
const enc = (s: string) => new TextEncoder().encode(s);
const pda = (seeds: (Uint8Array | Buffer)[]) => PublicKey.findProgramAddressSync(seeds, PROGRAM_ID)[0];

export const pdaRegistro = (nombre: string, owner: PublicKey) => pda([enc("registro"), enc(nombre), owner.toBytes()]);
export const pdaCliente = (reg: PublicKey, id: number) => pda([enc("cliente"), reg.toBytes(), u16(id)]);
export const pdaVenta = (cli: PublicKey, sku: string) => pda([enc("venta"), cli.toBytes(), enc(sku)]);
export const pdaProducto = (reg: PublicKey, sku: string) => pda([enc("producto"), reg.toBytes(), enc(sku)]);

export type Data = {
  registro: any; registroKey: PublicKey;
  clientes: { key: PublicKey; id: number; nombre: string; compras: number }[];
  ventas: { key: PublicKey; clienteId: number; clienteNombre: string; sku: string; descripcion: string; monto: number }[];
  productos: { key: PublicKey; sku: string; nombre: string; precio: number; stock: number }[];
};

export async function cargarTodo(program: any, nombre: string, owner: PublicKey): Promise<Data | null> {
  const registroKey = pdaRegistro(nombre, owner);
  const registro = await program.account.registro.fetchNullable(registroKey);
  if (!registro) return null;

  const cAcc: any[] = registro.clientes.length ? await program.account.cliente.fetchMultiple(registro.clientes) : [];
  const clientes = cAcc.map((c, i) => c && ({ key: registro.clientes[i], id: c.idCliente, nombre: c.nombre, compras: c.compras, historial: c.historial })).filter(Boolean) as any[];

  const ventaKeys: PublicKey[] = clientes.flatMap((c) => c.historial);
  const vAcc: any[] = ventaKeys.length ? await program.account.venta.fetchMultiple(ventaKeys) : [];
  const ventas: Data["ventas"] = [];
  let idx = 0;
  for (const c of clientes) for (const k of c.historial) {
    const v = vAcc[idx++];
    if (v) ventas.push({ key: k, clienteId: c.id, clienteNombre: c.nombre, sku: v.sku, descripcion: v.descripcion, monto: v.monto });
  }

  const pAcc = await program.account.producto.all([{ memcmp: { offset: 8, bytes: registroKey.toBase58() } }]);
  const productos = pAcc.map((p: any) => ({ key: p.publicKey, sku: p.account.sku, nombre: p.account.nombre, precio: p.account.precio, stock: p.account.stock }));

  return { registro, registroKey, clientes, ventas, productos };
}

export function mensajeError(e: any): string {
  const msg = e?.error?.errorMessage || e?.message || String(e);
  const log = (e?.logs || []).find((l: string) => l.includes("Error Message:"));
  return log ? log.split("Error Message:")[1].trim() : msg;
}
