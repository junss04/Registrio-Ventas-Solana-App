import { Buffer } from "buffer";
(window as any).Buffer = Buffer;
import React from "react";
import ReactDOM from "react-dom/client";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import "@solana/wallet-adapter-react-ui/styles.css";
import App from "./App";
import "./styles.css";

const RPC = import.meta.env.VITE_RPC_URL || "https://api.devnet.solana.com";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <ConnectionProvider endpoint={RPC}>
    <WalletProvider wallets={[]} autoConnect>
      <WalletModalProvider>
        <App />
      </WalletModalProvider>
    </WalletProvider>
  </ConnectionProvider>
);
