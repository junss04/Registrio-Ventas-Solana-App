# Frontend · Registro de Ventas (Solana)

React + Vite + Wallet Adapter + Anchor.

```bash
cd frontend
cp .env.example .env      # pega tu Program ID de Devnet
npm install
npm run dev               # http://localhost:5173
```

> `src/idl/registro.json` fue generado a partir del programa. Después de tu **Build/Deploy** en Playground,
> descarga el IDL real (pestaña Build & Deploy → *IDL*) y reemplaza ese archivo para que coincida al 100 %.
