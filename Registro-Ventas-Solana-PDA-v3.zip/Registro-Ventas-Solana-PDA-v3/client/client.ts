//////////////////// Imports ////////////////////
import { PublicKey } from "@solana/web3.js";

////////////////// Constantes ////////////////////
const nombre_negocio = "Abarrotes Tsting";
const owner = pg.wallet.publicKey;

//////////////////// Helpers ////////////////////
function u16ToBytes(valor) {
  const buffer = Buffer.alloc(2);
  buffer.writeUInt16LE(valor, 0); // little endian, igual que to_le_bytes() en Rust
  return buffer;
}
const pda = (seeds) => PublicKey.findProgramAddressSync(seeds, pg.PROGRAM_ID)[0];

// Jerarquia: registro <- cliente <- venta ; registro <- producto
const pdaRegistro = (nombre) => pda([Buffer.from("registro"), Buffer.from(nombre), owner.toBuffer()]);
const pdaCliente = (reg, id) => pda([Buffer.from("cliente"), reg.toBuffer(), u16ToBytes(id)]);
const pdaVenta = (cli, sku) => pda([Buffer.from("venta"), cli.toBuffer(), Buffer.from(sku)]);
const pdaProducto = (reg, sku) => pda([Buffer.from("producto"), reg.toBuffer(), Buffer.from(sku)]);

async function siguienteId(nombre) {
  const r = await pg.program.account.registro.fetch(pdaRegistro(nombre));
  return r.idCounter + 1;
}

//////////////////// Instrucciones ////////////////////
async function crearRegistro(nombre) {
  const tx = await pg.program.methods.crearRegistro(nombre)
    .accounts({ owner, registro: pdaRegistro(nombre) }).rpc();
  console.log("txHash:", tx);
}

async function crearCliente(nombre, nombreCliente) {
  const id = await siguienteId(nombre);
  const registro = pdaRegistro(nombre);
  const tx = await pg.program.methods.crearCliente(nombreCliente)
    .accounts({ owner, registro, cliente: pdaCliente(registro, id) }).rpc();
  console.log("txHash:", tx, "| cliente id:", id);
  return id;
}

// NUEVO: baja de cliente (solo si no tiene compras)
async function eliminarCliente(nombre, id) {
  const registro = pdaRegistro(nombre);
  const tx = await pg.program.methods.eliminarCliente(id)
    .accounts({ owner, registro, cliente: pdaCliente(registro, id) }).rpc();
  console.log("txHash:", tx);
}

// NUEVO: inventario
async function crearProducto(nombre, sku, nombreProd, precio, stock) {
  const registro = pdaRegistro(nombre);
  const tx = await pg.program.methods.crearProducto(sku, nombreProd, precio, stock)
    .accounts({ owner, registro, producto: pdaProducto(registro, sku) }).rpc();
  console.log("txHash:", tx);
}

async function reabastecerProducto(nombre, sku, cantidad) {
  const registro = pdaRegistro(nombre);
  const tx = await pg.program.methods.reabastecerProducto(sku, cantidad)
    .accounts({ owner, registro, producto: pdaProducto(registro, sku) }).rpc();
  console.log("txHash:", tx);
}

function cuentasVenta(nombre, id, sku) {
  const registro = pdaRegistro(nombre);
  const cliente = pdaCliente(registro, id);
  return { owner, registro, cliente, producto: pdaProducto(registro, sku), venta: pdaVenta(cliente, sku) };
}

async function registrarVenta(nombre, id, sku, descripcion, monto) {
  const tx = await pg.program.methods.registrarVenta(id, sku, descripcion, monto)
    .accounts(cuentasVenta(nombre, id, sku)).rpc();
  console.log("txHash:", tx);
}

async function hacerDevolucion(nombre, id, sku) {
  const tx = await pg.program.methods.hacerDevolucion(id, sku)
    .accounts(cuentasVenta(nombre, id, sku)).rpc();
  console.log("txHash:", tx);
}

async function cambiarMonto(nombre, id, sku, nuevoMonto) {
  const { owner: o, registro, cliente, venta } = cuentasVenta(nombre, id, sku);
  const tx = await pg.program.methods.cambiarMonto(id, sku, nuevoMonto)
    .accounts({ owner: o, registro, cliente, venta }).rpc();
  console.log("txHash:", tx);
}

//////////////////// Lectura ////////////////////
async function verClientes(nombre) {
  const reg = await pg.program.account.registro.fetch(pdaRegistro(nombre));
  console.log("Negocio:", reg.nombreNegocio, "| Ingresos:", reg.ingresosTotales.toString());
  for (const key of reg.clientes) {
    const c = await pg.program.account.cliente.fetch(key);
    console.log(`Cliente ${c.idCliente}: ${c.nombre} | compras: ${c.compras}`);
    for (const vk of c.historial) {
      const v = await pg.program.account.venta.fetch(vk);
      console.log(`   ${v.sku} | ${v.descripcion} | $${v.monto}`);
    }
  }
}

// Ejecuta en este orden (descomenta de a una):
crearRegistro(nombre_negocio);
// crearProducto(nombre_negocio, "Sabri", "Sabritas", 30, 10);
// crearCliente(nombre_negocio, "Isaac K");
// registrarVenta(nombre_negocio, 1, "Sabri", "No puedes comer solo una", 30);
// cambiarMonto(nombre_negocio, 1, "Sabri", 32);
// hacerDevolucion(nombre_negocio, 1, "Sabri");
// eliminarCliente(nombre_negocio, 1);
// verClientes(nombre_negocio);
