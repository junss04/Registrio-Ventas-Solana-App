// Pruebas en Solana Playground (web3, anchor, pg y assert son globales)
describe("Registro de ventas", () => {
  const nombre = "Tienda Test " + Math.floor(Math.random() * 10000);
  const owner = pg.wallet.publicKey;
  const u16 = (n) => { const b = Buffer.alloc(2); b.writeUInt16LE(n); return b; };
  const pda = (s) => web3.PublicKey.findProgramAddressSync(s, pg.PROGRAM_ID)[0];
  const registro = pda([Buffer.from("registro"), Buffer.from(nombre), owner.toBuffer()]);
  const cliente = (id) => pda([Buffer.from("cliente"), registro.toBuffer(), u16(id)]);
  const producto = (sku) => pda([Buffer.from("producto"), registro.toBuffer(), Buffer.from(sku)]);
  const venta = (id, sku) => pda([Buffer.from("venta"), cliente(id).toBuffer(), Buffer.from(sku)]);
  const rechaza = async (p, codigo) => {
    try { await p; } catch (e) { assert(String(e).includes(codigo), "Error esperado " + codigo + ", llego: " + e); return; }
    assert.fail("Debio fallar con " + codigo);
  };

  it("crea registro, producto (stock 1) y cliente", async () => {
    await pg.program.methods.crearRegistro(nombre).accounts({ owner, registro }).rpc();
    await pg.program.methods.crearProducto("A1", "Refresco", 20, 1).accounts({ owner, registro, producto: producto("A1") }).rpc();
    await pg.program.methods.crearCliente("Ana").accounts({ owner, registro, cliente: cliente(1) }).rpc();
    assert.equal((await pg.program.account.producto.fetch(producto("A1"))).stock, 1);
  });

  it("registra venta: baja stock y suma ingresos", async () => {
    await pg.program.methods.registrarVenta(1, "A1", "Refresco 600ml", 20)
      .accounts({ owner, registro, cliente: cliente(1), producto: producto("A1"), venta: venta(1, "A1") }).rpc();
    assert.equal((await pg.program.account.producto.fetch(producto("A1"))).stock, 0);
    assert.equal((await pg.program.account.registro.fetch(registro)).ingresosTotales.toNumber(), 20);
  });

  it("RECHAZA venta sin stock (SinStock)", async () => {
    await pg.program.methods.crearCliente("Beto").accounts({ owner, registro, cliente: cliente(2) }).rpc();
    await rechaza(
      pg.program.methods.registrarVenta(2, "A1", "otra", 20)
        .accounts({ owner, registro, cliente: cliente(2), producto: producto("A1"), venta: venta(2, "A1") }).rpc(),
      "SinStock");
  });

  it("RECHAZA cambiar monto a 0 (MontoInvalido)", async () => {
    await rechaza(
      pg.program.methods.cambiarMonto(1, "A1", 0).accounts({ owner, registro, cliente: cliente(1), venta: venta(1, "A1") }).rpc(),
      "MontoInvalido");
  });

  it("RECHAZA baja de cliente con compras (ClienteConCompras)", async () => {
    await rechaza(
      pg.program.methods.eliminarCliente(1).accounts({ owner, registro, cliente: cliente(1) }).rpc(),
      "ClienteConCompras");
  });

  it("devolucion restaura stock y permite la baja del cliente", async () => {
    await pg.program.methods.hacerDevolucion(1, "A1")
      .accounts({ owner, registro, cliente: cliente(1), producto: producto("A1"), venta: venta(1, "A1") }).rpc();
    assert.equal((await pg.program.account.producto.fetch(producto("A1"))).stock, 1);
    await pg.program.methods.eliminarCliente(1).accounts({ owner, registro, cliente: cliente(1) }).rpc();
    const reg = await pg.program.account.registro.fetch(registro);
    assert.equal(reg.clientes.length, 1); // solo queda Beto
  });
});
