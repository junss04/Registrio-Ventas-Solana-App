use anchor_lang::prelude::*;

declare_id!("");

#[program]
pub mod registro {
    use super::*;

    /////////////////////////// Crear Registro ///////////////////////////
    pub fn crear_registro(context: Context<NuevoRegistro>, nombre_negocio: String) -> Result<()> {
        context.accounts.registro.set_inner(Registro {
            owner: context.accounts.owner.key(),
            nombre_negocio: nombre_negocio.clone(),
            clientes: Vec::new(),
            id_counter: 0,
            ingresos_totales: 0,
        });
        msg!("Registro: {} creado exitosamente!", nombre_negocio);
        Ok(())
    }

    /////////////////////////// Nuevo Cliente ///////////////////////////
    pub fn crear_cliente(context: Context<NuevoCliente>, nombre: String) -> Result<()> {
        let cliente_key = context.accounts.cliente.key();
        let registro = &mut context.accounts.registro;

        // NUEVO: regla de negocio, el indice de clientes tiene capacidad maxima
        require!(
            registro.clientes.len() < MAX_CLIENTES,
            Errores::RegistroLleno
        );

        let id_cliente = registro.id_counter + 1;
        registro.id_counter = id_cliente;
        registro.clientes.push(cliente_key);

        context.accounts.cliente.set_inner(Cliente {
            id_cliente,
            nombre: nombre.clone(),
            compras: 0,
            historial: Vec::new(),
        });

        msg!("Cliente {} creado con id: {}", nombre, id_cliente);
        Ok(())
    }

    /////////////////////////// Eliminar Cliente (BAJA) ///////////////////////////
    // Se cierra la cuenta del cliente SOLO si no tiene compras vigentes.
    pub fn eliminar_cliente(context: Context<EliminarCliente>, _id_cliente: u16) -> Result<()> {
        let cliente_key = context.accounts.cliente.key();

        // Regla: un cliente con ventas en su historial no puede darse de baja
        require!(
            context.accounts.cliente.compras == 0 && context.accounts.cliente.historial.is_empty(),
            Errores::ClienteConCompras
        );

        let registro = &mut context.accounts.registro;
        registro.clientes.retain(|&k| k != cliente_key); // Mantiene el indice sincronizado

        msg!("Cliente {} dado de baja", context.accounts.cliente.id_cliente);
        Ok(())
    }

    /////////////////////////// Crear Producto (NUEVO MODULO: inventario) ///////////////////////////
    pub fn crear_producto(
        context: Context<NuevoProducto>,
        sku: String,
        nombre: String,
        precio: u32,
        stock: u16,
    ) -> Result<()> {
        require!(precio > 0, Errores::MontoInvalido);
        require!(!sku.is_empty(), Errores::SkuInvalido);

        context.accounts.producto.set_inner(Producto {
            registro: context.accounts.registro.key(),
            sku: sku.clone(),
            nombre,
            precio,
            stock,
        });
        msg!("Producto {} creado con stock {}", sku, stock);
        Ok(())
    }

    /////////////////////////// Reabastecer Producto ///////////////////////////
    pub fn reabastecer_producto(
        context: Context<ModificarProducto>,
        _sku: String,
        cantidad: u16,
    ) -> Result<()> {
        require!(cantidad > 0, Errores::MontoInvalido);
        let producto = &mut context.accounts.producto;
        producto.stock = producto
            .stock
            .checked_add(cantidad)
            .ok_or(Errores::Desbordamiento)?;
        msg!("Stock de {} ahora: {}", producto.sku, producto.stock);
        Ok(())
    }

    /////////////////////////// Registrar Venta ///////////////////////////
    // Ahora valida monto > 0, historial no lleno y descuenta 1 unidad del inventario.
    pub fn registrar_venta(
        context: Context<NuevaVenta>,
        _id_cliente: u16,
        sku: String,
        descripcion: String,
        monto: u32,
    ) -> Result<()> {
        require!(monto > 0, Errores::MontoInvalido);
        require!(
            context.accounts.cliente.historial.len() < MAX_HISTORIAL,
            Errores::HistorialLleno
        );
        require!(context.accounts.producto.stock > 0, Errores::SinStock);

        context.accounts.venta.set_inner(Venta { sku, descripcion, monto });
        let venta_key = context.accounts.venta.key();

        let cliente = &mut context.accounts.cliente;
        cliente.historial.push(venta_key);
        cliente.compras += 1;

        context.accounts.producto.stock -= 1;

        let registro = &mut context.accounts.registro;
        registro.ingresos_totales = registro.ingresos_totales.saturating_add(monto as u64);

        msg!("Venta registrada para el cliente con id: {}", cliente.id_cliente);
        Ok(())
    }

    /////////////////////////// Hacer Devolucion ///////////////////////////
    pub fn hacer_devolucion(
        context: Context<EliminarVenta>,
        _id_cliente: u16,
        sku: String,
    ) -> Result<()> {
        let venta_key = context.accounts.venta.key();
        let monto = context.accounts.venta.monto as u64;

        let cliente = &mut context.accounts.cliente;
        require!(cliente.historial.contains(&venta_key), Errores::NoSKU);
        cliente.historial.retain(|&k| k != venta_key);
        cliente.compras -= 1;

        // La mercancia regresa al inventario y los ingresos se ajustan
        context.accounts.producto.stock += 1;
        let registro = &mut context.accounts.registro;
        registro.ingresos_totales = registro.ingresos_totales.saturating_sub(monto);

        msg!("Venta con sku: {}, devuelta por el cliente con id: {}", sku, cliente.id_cliente);
        Ok(())
    }

    /////////////////////////// Cambiar Monto ///////////////////////////
    pub fn cambiar_monto(
        context: Context<ModificarVenta>,
        _id_cliente: u16,
        sku: String,
        nuevo_monto: u32,
    ) -> Result<()> {
        require!(nuevo_monto > 0, Errores::MontoInvalido);

        let venta = &mut context.accounts.venta;
        let viejo_monto = venta.monto;
        venta.monto = nuevo_monto;

        let registro = &mut context.accounts.registro;
        registro.ingresos_totales = registro
            .ingresos_totales
            .saturating_sub(viejo_monto as u64)
            .saturating_add(nuevo_monto as u64);

        msg!("El monto de la venta con sku: {}, paso de: {}, a: {}", sku, viejo_monto, nuevo_monto);
        Ok(())
    }
}

pub const MAX_CLIENTES: usize = 10;
pub const MAX_HISTORIAL: usize = 10;

/////////////////////////// Codigos de Error ///////////////////////////
#[error_code]
pub enum Errores {
    #[msg("Error, no eres el owner del registro")]
    NoOwner,
    #[msg("Error, la venta no esta en el historial del cliente")]
    NoSKU,
    #[msg("Error, el monto o la cantidad debe ser mayor a cero")]
    MontoInvalido,
    #[msg("Error, el registro alcanzo el maximo de clientes")]
    RegistroLleno,
    #[msg("Error, el historial del cliente esta lleno")]
    HistorialLleno,
    #[msg("Error, no se puede dar de baja un cliente con compras")]
    ClienteConCompras,
    #[msg("Error, el producto no tiene stock")]
    SinStock,
    #[msg("Error, el SKU no puede estar vacio")]
    SkuInvalido,
    #[msg("Error, desbordamiento numerico")]
    Desbordamiento,
}

/////////////////////////// CUENTAS ///////////////////////////
#[account]
#[derive(InitSpace)]
pub struct Registro {
    pub owner: Pubkey,
    #[max_len(30)]
    pub nombre_negocio: String,
    #[max_len(10)]
    pub clientes: Vec<Pubkey>,
    pub id_counter: u16,
    pub ingresos_totales: u64, // NUEVO: reporte on-chain
}

#[account]
#[derive(InitSpace, PartialEq)]
pub struct Cliente {
    pub id_cliente: u16,
    #[max_len(30)]
    pub nombre: String,
    pub compras: u16,
    #[max_len(10)]
    pub historial: Vec<Pubkey>,
}

#[account]
#[derive(InitSpace, PartialEq)]
pub struct Venta {
    #[max_len(5)]
    pub sku: String,
    #[max_len(50)]
    pub descripcion: String,
    pub monto: u32,
}

// NUEVO: inventario. "registro" va primero para poder filtrar con memcmp (offset 8) desde el front
#[account]
#[derive(InitSpace, PartialEq)]
pub struct Producto {
    pub registro: Pubkey,
    #[max_len(5)]
    pub sku: String,
    #[max_len(30)]
    pub nombre: String,
    pub precio: u32,
    pub stock: u16,
}

/////////////////////////// CONTEXTOS ///////////////////////////
/*
    registro  <- [b"registro", nombre_negocio, owner]
    cliente   <- [b"cliente",  registro, id_cliente]
    venta     <- [b"venta",    cliente,  sku]
    producto  <- [b"producto", registro, sku]
*/

#[derive(Accounts)]
#[instruction(nombre_negocio: String)]
pub struct NuevoRegistro<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(
        init, payer = owner, space = Registro::INIT_SPACE + 8,
        seeds = [b"registro", nombre_negocio.as_bytes(), owner.key().as_ref()], bump
    )]
    pub registro: Account<'info, Registro>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct NuevoCliente<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>,
    #[account(
        init, payer = owner, space = Cliente::INIT_SPACE + 8,
        seeds = [b"cliente", registro.key().as_ref(), (registro.id_counter + 1).to_le_bytes().as_ref()], bump
    )]
    pub cliente: Account<'info, Cliente>,
    pub system_program: Program<'info, System>,
}

/// Instruccion: eliminar_cliente -> cierra la cuenta del cliente
#[derive(Accounts)]
#[instruction(id_cliente: u16)]
pub struct EliminarCliente<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>,
    #[account(
        mut, close = owner,
        seeds = [b"cliente", registro.key().as_ref(), id_cliente.to_le_bytes().as_ref()], bump
    )]
    pub cliente: Account<'info, Cliente>,
}

#[derive(Accounts)]
#[instruction(sku: String)]
pub struct NuevoProducto<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>,
    #[account(
        init, payer = owner, space = Producto::INIT_SPACE + 8,
        seeds = [b"producto", registro.key().as_ref(), sku.as_bytes()], bump
    )]
    pub producto: Account<'info, Producto>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(sku: String)]
pub struct ModificarProducto<'info> {
    pub owner: Signer<'info>,
    #[account(has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>,
    #[account(
        mut,
        seeds = [b"producto", registro.key().as_ref(), sku.as_bytes()], bump
    )]
    pub producto: Account<'info, Producto>,
}

#[derive(Accounts)]
#[instruction(id_cliente: u16, sku: String)]
pub struct NuevaVenta<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>, // mut: acumula ingresos_totales
    #[account(
        mut,
        seeds = [b"cliente", registro.key().as_ref(), id_cliente.to_le_bytes().as_ref()], bump
    )]
    pub cliente: Account<'info, Cliente>,
    #[account(
        mut,
        seeds = [b"producto", registro.key().as_ref(), sku.as_bytes()], bump
    )]
    pub producto: Account<'info, Producto>,
    #[account(
        init, payer = owner, space = Venta::INIT_SPACE + 8,
        seeds = [b"venta", cliente.key().as_ref(), sku.as_bytes()], bump
    )]
    pub venta: Account<'info, Venta>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(id_cliente: u16, sku: String)]
pub struct ModificarVenta<'info> {
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>, // mut: ajusta ingresos_totales
    #[account(
        seeds = [b"cliente", registro.key().as_ref(), id_cliente.to_le_bytes().as_ref()], bump
    )]
    pub cliente: Account<'info, Cliente>,
    #[account(
        mut,
        seeds = [b"venta", cliente.key().as_ref(), sku.as_bytes()], bump
    )]
    pub venta: Account<'info, Venta>,
}

#[derive(Accounts)]
#[instruction(id_cliente: u16, sku: String)]
pub struct EliminarVenta<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,
    #[account(mut, has_one = owner @ Errores::NoOwner)]
    pub registro: Account<'info, Registro>,
    #[account(
        mut,
        seeds = [b"cliente", registro.key().as_ref(), id_cliente.to_le_bytes().as_ref()], bump
    )]
    pub cliente: Account<'info, Cliente>,
    #[account(
        mut,
        seeds = [b"producto", registro.key().as_ref(), sku.as_bytes()], bump
    )]
    pub producto: Account<'info, Producto>,
    #[account(
        mut, close = owner,
        seeds = [b"venta", cliente.key().as_ref(), sku.as_bytes()], bump
    )]
    pub venta: Account<'info, Venta>,
}
