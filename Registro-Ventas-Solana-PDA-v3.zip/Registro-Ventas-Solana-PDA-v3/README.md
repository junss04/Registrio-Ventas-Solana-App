# Registro de Ventas en Solana con PDAs

![banner](./images/banner.jpg)

CRUD básico de un Solana Program desarrollado con Rust y Anchor desde el Solana Playground. 

Puedes comenzar dándole Fork a este repositorio (abajo te explicamos como 👇), **hemos preparado un entorno de codespaces listo para que no tengas que instalar nada**, solo déjate llevar por la fluidez de los ejercicios y temas desarrollados especialmente para ti. 

Asegúrate de clonar este repositorio a tu cuenta usando el botón **`Fork`**.

![fork](./images/fork.png)

## Importando el proyecto 

Ya con el repositorio en tu cuenta lo siguiente que debes hacer copiar el `enlace de tu repositorio`, lo que se puede hacer directamente desdel navegador:

![repo](./images/repo.png)

Posteriormente, lo uniremos con el siguiente enlace en nuestro navegador de preferencia:

```url
https://beta.solpg.io/
```

Lo que nos dará algo parecido a:

![url](./images/url.png)

Puedes importar directamenet el proyecto al `Solana Playground` dando clic al siguiente enlace 👇:

[ 🔗 Importar repositorio al Playground ](https://beta.solpg.io/https://github.com/WayLearnLatam/Registro-Ventas-Solana-PDA)

Al pulsar enter seremos enviados al `Solana Playground` con nuestro proyecto abierto:

![pg](./images/pg.png)

Para guardarlo solo damos clic en el boton `import` y asignamos un nombre:

![import](./images/import.png)

## Preparacion del entorno

Primero conectaremos el entorno con la devnet, lo que tambien procederá a la creación de una wallet. Para eso daremos clic en donde dice **Not Conected**:

![playground1](./images/playground1.png)

Saldrá la siguiente ventana donde daremos en el botón **Continue**:

![wallet](./images/wallet.png)

Como resultado se mostrará la siguiente información:

![status](./images/status.png)

* En verde: el estado de la conexión y el entorno al que se encuentra conectado

* En amarillo: la la dirección de la wallet conectada

* En azul: la cantidad de tokens en la wallet

> ℹ️ ¿Quieres ver el ejemplo de un "Hola Mundo" en Solana?. Da clic aquí: 👉 [Ver Ejemplo](https://github.com/WayLearnLatam/Solana-starter-kit/tree/1fc6349ba63375a3fe223d8d56911bc64765459b/build-deploy)


---

## 🧩 Ruta del proyecto final: guiado + mejora funcional

**Base de partida:** registro de ventas del bootcamp (registro → cliente → venta, PDAs jerárquicas, `crear_registro`, `crear_cliente`, `registrar_venta`, `cambiar_monto`, `hacer_devolucion`).

### Qué se añadió (aporte propio)
| Módulo | Instrucciones / cambios | Cómo comprobarlo |
|---|---|---|
| **Baja de cliente** | `eliminar_cliente` (cierra la PDA, `close = owner`). Rechaza con `ClienteConCompras` si tiene compras | test "RECHAZA baja de cliente con compras" y luego baja exitosa tras devolución |
| **Inventario** | Cuenta `Producto` (PDA `[producto, registro, sku]`), `crear_producto`, `reabastecer_producto` | tests + pestaña *Productos* |
| **Venta con stock** | `registrar_venta` descuenta stock; `hacer_devolucion` lo restaura. Rechazo `SinStock` | test "RECHAZA venta sin stock" |
| **Validaciones de negocio** | `MontoInvalido` (monto/cantidad > 0), `RegistroLleno`, `HistorialLleno`, `SkuInvalido` | test "RECHAZA cambiar monto a 0" |
| **Reporte on-chain** | `Registro.ingresos_totales` se mantiene en venta, devolución y cambio de monto | Dashboard del frontend |
| **Frontend** | Wallet, firma/confirmación, refresco de datos, errores del programa, enlace al explorer, export CSV | `frontend/` |

### Cómo ejecutarlo
1. Importa el repo en Solana Playground → **Build** → **Deploy** (Devnet). Anota el **Program ID**.
2. Ejecuta `tests/anchor.test.ts` (botón *Test*) y guarda las capturas / txs.
3. Frontend: ver `frontend/README.md`.

### Evidencias (completa antes de enviar)
- Program ID (Devnet): `...`
- Tx crear registro: `...`
- Tx registrar venta: `...`
- Tx rechazada (SinStock / ClienteConCompras): `...`
- Tx baja de cliente: `...`

> Uso de IA: revisé, entendí y probé los cambios integrados.


---

## 🖥️ Cómo ver la interfaz (sin npm)

`index.html` (en la raíz) es una interfaz completa que habla directo con el programa. Está conectada a las 8 instrucciones de `src/lib.rs`.

1. Haz **Build + Deploy** en Solana Playground (Devnet) y copia el **Program ID**.
2. En VS Code instala **Live Server**, clic derecho en `index.html` → *Open with Live Server*.
3. Conecta Phantom (Devnet), pega el Program ID, escribe el nombre del negocio y pulsa **Abrir negocio**.

> No abras el archivo con doble clic: la wallet no se inyecta en páginas `file://`.

La versión React (`frontend/`) hace lo mismo y requiere `npm install && npm run dev`.
